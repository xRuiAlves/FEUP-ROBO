roslaunch robo open_D_shape.launch \
    wall_thickness:=0.5 \
    x_pos:=0.5 \
    y_pos:=0 \
    z_pos:=0 \
    angle:=3.1415