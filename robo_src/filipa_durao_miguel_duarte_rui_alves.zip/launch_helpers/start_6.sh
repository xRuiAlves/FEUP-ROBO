roslaunch robo open_D_shape.launch \
    wall_thickness:=0.6 \
    x_pos:=0 \
    y_pos:=0 \
    z_pos:=0 \
    angle:=0